﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("Outercurve Foundation")]
[assembly: AssemblyProduct("NuGet Package Explorer")]
[assembly: AssemblyCopyright("\x00a9 Outercurve Foundation. All rights reserved.")]
[assembly: AssemblyTitle("NuGetPackageExplorer.Types")]
[assembly: AssemblyDescription("Contains types to enable the plugin architecture in NuGet Package Explorer.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
//keep in sync with PackageExplorer\app.config
[assembly: AssemblyVersion("5.0.0.0")]
[assembly: AssemblyFileVersion("5.0.0.0")]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("8bdc7953-73c3-47d6-b0c5-41fda3d55e42")]