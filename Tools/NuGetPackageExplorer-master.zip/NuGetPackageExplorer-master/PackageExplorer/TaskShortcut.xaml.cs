﻿using System.Windows.Controls;

namespace PackageExplorer
{
    /// <summary>
    /// Interaction logic for TaskShortcut.xaml
    /// </summary>
    public partial class TaskShortcut : UserControl
    {
        public TaskShortcut()
        {
            InitializeComponent();
        }
    }
}