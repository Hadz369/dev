using System.Reflection;
using System.Resources;
using System.Runtime.InteropServices;

[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("NuGet Package Explorer")]
[assembly: AssemblyCopyright("NPE. All rights reserved.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: NeutralResourcesLanguage("en-US")]
[assembly: AssemblyVersion("3.22.0.0")]
[assembly: AssemblyFileVersion("3.22.0.0")]