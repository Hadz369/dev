﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("PackageViewModel")]
[assembly: AssemblyDescription("Contains ViewModel classes for the main application.")]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("feba71bb-eafd-42ef-b9b1-6eee1ab96c86")]