﻿namespace NuGet
{
    public enum CredentialType
    {
        ProxyCredentials,
        RequestCredentials
    }
}
