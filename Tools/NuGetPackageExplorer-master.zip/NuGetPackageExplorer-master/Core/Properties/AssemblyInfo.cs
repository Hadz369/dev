﻿using System.Reflection;
using System.Runtime.InteropServices;

// General Information about an assembly is controlled through the following 
// set of attributes. Change these attribute values to modify the information
// associated with an assembly.

[assembly: AssemblyTitle("NuGet Package Explorer Core")]
[assembly: AssemblyDescription("Core library which is responsible for loading .nupkg files and parsing .nuspec files.")]

// The following GUID is for the ID of the typelib if this project is exposed to COM

[assembly: Guid("d09c04cc-578b-49f3-b2e5-16b9e55d73f9")]